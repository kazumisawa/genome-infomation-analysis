def putOrder(DFSresult):
    for i in range( len(DFSresult) ):
        DFSresult[i].order = i

