from Bio.SubsMat import MatrixInfo
print(MatrixInfo.pam250)
