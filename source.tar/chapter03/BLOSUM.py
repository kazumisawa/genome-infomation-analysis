from Bio.SubsMat import MatrixInfo
print(MatrixInfo.blosum62)
