def score(char1, char2):
    if char1==char2:
        return 1
    else:
        return 0
