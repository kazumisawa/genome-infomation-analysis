import time

start_time = time.time()
#作業
end_time = time.time()
print( end_time - start_time )
Hello!
e134ced312b3511d88943d57ccd70c83  data.txt
Hello.
5083abdbc540c4a95ea195be6e3a9489  data2.txt
Algorithm   Hash                              Path
---------   ----                              ----
MD5         E134CED312B3511D88943D57CCD70C83  hello.txt
