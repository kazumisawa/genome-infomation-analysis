from Bio.Alphabet import IUPAC
print(IUPAC.IUPACUnambiguousDNA.letters)
print(IUPAC.IUPACUnambiguousRNA.letters)
print(IUPAC.IUPACProtein.letters)
